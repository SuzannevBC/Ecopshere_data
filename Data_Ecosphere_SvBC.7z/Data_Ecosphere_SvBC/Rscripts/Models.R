library(lme4)
library(dfoptim)
library(optimx)
library(DHARMa)
library(effects)
library(glmmTMB)
library(MCMCglmm)
library(pscl)
library(jtools)
library(plyr)
library(scales)
library(dplyr)
library(MuMIn)
library(nlme)
library(lmtest)
library(raster)
library(sp)
library(rgdal)
library(rgeos)

# ----------------------------------------------------------------------------------------------------
#### Load data ####
# ----------------------------------------------------------------------------------------------------
BI_T_BF_ca2<- read.csv("Data\\Browsing_landscape.csv", header = T, sep = ",")
BI_T_BF_ca2<- BI_T_BF_ca2[,-1]
BI_BF_ca2<- read.csv("Data\\Browsing_finescale.csv", header = T, sep = ",")
BI_BF_ca2<- BI_BF_ca2[,-1]
Quality_BF_ca2<- read.csv("Data\\Diet_quality.csv", header = T, sep = ",")
Quality_BF_ca2<- Quality_BF_ca2[,-1]
Quality_JS_BF_rev<- read.csv("Data\\Food_selection.csv", header = T, sep = ",")
Quality_JS_BF_rev<- Quality_JS_BF_rev[,-1]

# ----------------------------------------------------------------------------------------------------
#### Browsing intensity ####
# ----------------------------------------------------------------------------------------------------

#### Landscape scale #### ----------------------------------------------------------------------------
BI_T_BF_ca2<- BI_T_BF_ca2[!is.na(BI_T_BF_ca2$Avg_rating_Tourism),] # otherwise problem with model comparison, due to NA Tourism 


BIl_all_wr<- glmmTMB(cbind(total_browsed, total_available - total_browsed) ~ scale(Lynx_suit_night) + scale(Avg_dist_cull) + + scale(I(sqrt(Dist_Sett))) + scale(Avg_rating_Tourism), data = BI_T_BF_ca2, family = "betabinomial")

sim_BIl_all_wr<- simulateResiduals(BIl_all_wr)
x11()
plot(sim_BIl_all_wr)

summary(BIl_all_wr)

#### Fine scale #### --------------------------------------------------------------------------------

BI_BF_ca2$Avg_visibility<- (BI_BF_ca2$Visibility_roe + BI_BF_ca2$Visibility_red)/2

BI_plot_inter_nrev<- glmmTMB(cbind(total_browsed, total_available - total_browsed) ~  scale(Avg_visibility):scale(Lynx_suit_night) + scale(Avg_visibility):scale(I(sqrt(Avg_dist_cull))) + scale(Avg_visibility):scale(Avg_rating_Tourism) + scale(Avg_visibility):scale(I(sqrt(Dist_Sett))) + scale(Solar_rad) + scale(Elevation) + scale(Tree_density) + scale(tree_height.cm.) + Tree_spp_english + (1|Transect_Nr/Plot),  data = BI_BF_ca2, family = "betabinomial")

sim_BIplot<- simulateResiduals(BI_plot_inter_nrev) 
x11()
plot(sim_BIplot)

testOutliers(sim_BIplot, type = c("bootstrap"))
# plotResiduals(sim_BIplot, BI_BF_ca$Avg_visibility)
# plotResiduals(sim_BIplot, BI_BF_ca$Lynx_suit_night)
# plotResiduals(sim_BIplot, BI_BF_ca$Avg_dist_cull)
# plotResiduals(sim_BIplot, BI_BF_ca$Avg_rating_Tourism)
# plotResiduals(sim_BIplot, BI_BF_ca$Dist_Sett)
# plotResiduals(sim_BIplot, BI_BF_ca$Solar_rad)
# plotResiduals(sim_BIplot, BI_BF_ca$Elevation)
# plotResiduals(sim_BIplot, BI_BF_ca$Tree_density)
# plotResiduals(sim_BIplot, BI_BF_ca$tree_height.cm.)
# plotResiduals(sim_BIplot, BI_BF_ca$Tree_spp_english)

summary(BI_plot_inter_nrev)

# ----------------------------------------------------------------------------------------------------
#### Diet quality ####
# ----------------------------------------------------------------------------------------------------

# Happened with merging of spatial data, only names changed which were later used in models
names(Quality_BF_ca2)[names(Quality_BF_ca2) == "C.N_ratio.x"]<- "C.N_ratio"
names(Quality_BF_ca2)[names(Quality_BF_ca2) == "avg.NDF.x"]<- "avg.NDF"
names(Quality_BF_ca2)[names(Quality_BF_ca2) == "avg.ADF.x"]<- "avg.ADF"
names(Quality_BF_ca2)[names(Quality_BF_ca2) == "avg.Lignin.x"]<- "avg.Lignin"
names(Quality_BF_ca2)[names(Quality_BF_ca2) == "Hunting.x"]<- "Hunting"
names(Quality_BF_ca2)[names(Quality_BF_ca2) == "Deer_species.x"]<- "Deer_species"

# Remove NA's Tourism due to model comparison
Quality_BF_ca2<- Quality_BF_ca2[!is.na(Quality_BF_ca2$Avg_rating_Tourism),]

#### C/N ratio #### ---------------------------------------------------------------------------------

CN_interall<- lmer(C.N_ratio ~ scale(Lynx_suit_night)*Deer_species + scale(Avg_dist_cull)*Deer_species + scale(I(sqrt(Dist_Sett)))*Deer_species + scale(Avg_rating_Tourism)*Deer_species+ (1|Transect_Nr), data = Quality_BF_ca2)

CN_lme_interall<- lme(C.N_ratio ~ scale(Lynx_suit_night)*Deer_species + scale(Avg_dist_cull)*Deer_species + scale(I(sqrt(Dist_Sett)))*Deer_species + scale(Avg_rating_Tourism)*Deer_species, ~1|Transect_Nr, data = Quality_BF_ca2)

summary(CN_lme_interall)

#### ADF #### ---------------------------------------------------------------------------------------

ADF_allinter<- lmer(avg.ADF ~ scale(Lynx_suit_night)*Deer_species + scale(Avg_dist_cull)*Deer_species + scale(I(sqrt(Dist_Sett)))*Deer_species + scale(Avg_rating_Tourism)*Deer_species + (1|Transect_Nr), data = Quality_BF_ca2) 

test_ADF_interall<- simulateResiduals(ADF_allinter) 
x11()
plot(test_ADF_interall)

ADF_lme_interall<- lme(avg.ADF ~ scale(Lynx_suit_night)*Deer_species + scale(Avg_dist_cull)*Deer_species + scale(I(sqrt(Dist_Sett)))*Deer_species + scale(Avg_rating_Tourism)*Deer_species, ~1|Transect_Nr, data = Quality_BF_ca2)

summary(ADF_lme_interall)

#### NDF #### --------------------------------------------------------------------------------------

NDF_allinter<- lmer(avg.NDF ~ scale(Lynx_suit_night)*Deer_species + scale(Avg_dist_cull)*Deer_species + scale(I(sqrt(Dist_Sett)))*Deer_species + scale(Avg_rating_Tourism)*Deer_species + (1|Transect_Nr), data = Quality_BF_ca2) 

test_NDF_interall<- simulateResiduals(NDF_allinter) ### Problems detected --> CHECK
x11()
plot(test_NDF_interall)

testDispersion(test_NDF_interall)
testOutliers(test_NDF_interall, type = c("bootstrap"))
plotResiduals(test_NDF_interall, Quality_BF_ca2$Lynx_suit_night)
plotResiduals(test_NDF_interall, Quality_BF_ca2$Avg_dist_cull)
plotResiduals(test_NDF_interall, Quality_BF_ca2$Dist_Sett)
plotResiduals(test_NDF_interall, Quality_BF_ca2$Avg_rating_Tourism)
plotResiduals(test_NDF_interall, Quality_BF_ca2$Deer_species)

NDF_lme_interall<- lme(avg.NDF ~ scale(Lynx_suit_night)*Deer_species + scale(Avg_dist_cull)*Deer_species + scale(I(sqrt(Dist_Sett)))*Deer_species + scale(Avg_rating_Tourism)*Deer_species, ~1|Transect_Nr, data = Quality_BF_ca2)

summary(NDF_lme_interall)

#### Lignin #### ---------------------------------------------------------------------------------

Lignin_allinter<- lmer(avg.Lignin ~ scale(Lynx_suit_night)*Deer_species + scale(Avg_dist_cull)*Deer_species + scale(I(sqrt(Dist_Sett)))*Deer_species + scale(Avg_rating_Tourism)*Deer_species + (1|Transect_Nr), data = Quality_BF_ca2) 

test_Lignin_interall<- simulateResiduals(Lignin_allinter) 
x11()
plot(test_Lignin_interall)

Lignin_lme_interall<- lme(avg.Lignin ~ scale(Lynx_suit_night)*Deer_species + scale(Avg_dist_cull)*Deer_species + scale(I(sqrt(Dist_Sett)))*Deer_species + scale(Avg_rating_Tourism)*Deer_species, ~1|Transect_Nr, data = Quality_BF_ca2)

summary(Lignin_lme_interall)

# ---------------------------------------------------------------------------------------------------
#### Food source selection
# ---------------------------------------------------------------------------------------------------
# Divide dataset preferred and avoided tree species based on descriptives and Jacob`s selectivity plot
Preferred_Ebr_rev<- Quality_JS_BF_rev[which(Quality_JS_BF_rev$Tree_spp_english == "European beech" | Quality_JS_BF_rev$Tree_spp_english == "rowan"),]
Avoided_Nssf_rev<- Quality_JS_BF_rev[which(Quality_JS_BF_rev$Tree_spp_english == "Norway spruce" | Quality_JS_BF_rev$Tree_spp_english == "silver fir"),]


#### Preferred ####
JI_all_prefBI<- glmmTMB(cbind(total_browsed, total_available - total_browsed) ~ scale(Lynx_suit_night) + scale(Avg_dist_cull) + scale(I(sqrt(Dist_Sett))) + scale(Avg_rating_Tourism)+ (1|Transect_Nr), data = Preferred_Ebr_rev, family = "betabinomial")

sim_JI_pref3<- simulateResiduals(JI_all_prefBI) 
x11()
plot(sim_JI_pref3)

testDispersion(sim_JI_pref3)

plotResiduals(sim_JI_pref3, Preferred_Ebr_rev$Lynx_suit_night)
plotResiduals(sim_JI_pref3, Preferred_Ebr_rev$Avg_dist_cull)
plotResiduals(sim_JI_pref3, Preferred_Ebr_rev$Dist_Sett)
plotResiduals(sim_JI_pref3, Preferred_Ebr_rev$Avg_rating_Tourism)

summary(JI_all_prefBI)

#### Less preferred ####

JI_all_avBI<- glmmTMB(cbind(total_browsed, total_available - total_browsed) ~ scale(Lynx_suit_night) + scale(Avg_dist_cull) + scale(I(sqrt(Dist_Sett))) + scale(Avg_rating_Tourism)+ (1|Transect_Nr), ziformula = ~1 ,data = Avoided_Nssf_rev, family = "betabinomial")

sim_JI_av3<- simulateResiduals(JI_all_avBI) 
x11()
plot(sim_JI_av3)

summary(JI_all_avBI)